/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test_k2;

/**
 *
 * @author ADMIN
 */
public class Sach extends TaiLieu implements ITaiLieu{
    private String tenSach ;
    private String tenTG ;
    private int soTrang ;

    public Sach() {
    }

    public Sach(String tenSach, String tenTG, String tenNhaXB, int soTrang, int soBanPH) {
        super(tenNhaXB, soBanPH);
        this.tenSach = tenSach;
        this.tenTG = tenTG;
        this.soTrang = soTrang;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public String getTenTG() {
        return tenTG;
    }

    public void setTenTG(String tenTG) {
        this.tenTG = tenTG;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }
    public String chuanHoa(){
        String [] s = getTenTG().toUpperCase().split("\\s+");
        String res = s[s.length - 1];
        return res;
    }
    public void setMa(){
        ma = chuanHoa() + getMa();
        super.setMa();
    }
    @Override
    public String toString() {
        return getMa()+" "+getTenSach()+" "+getTenTG()+" "+getTenNhaXB()+" "+getSoBanPH() ;
    }

//    @Override
//    public int SoAnPham() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
    
}
